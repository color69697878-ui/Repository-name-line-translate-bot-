# LINE 即時翻譯 Bot（可直接部署）

## 功能
- 自動偵測語言
- 自動翻譯
- LINE 即時回覆
- 可部署到 Render / Railway / VPS

---

## 1️⃣ 安裝
```
npm install
```

---

## 2️⃣ 設定環境變數
複製 `.env.example` → `.env`

填入：

- LINE_CHANNEL_ACCESS_TOKEN
- LINE_CHANNEL_SECRET
- OPENAI_API_KEY
- TARGET_LANGUAGE (例如 zh-TW / en / ja)

---

## 3️⃣ 本機啟動
```
npm start
```

---

## 4️⃣ Webhook 設定
LINE Developers → Messaging API

Webhook URL：
```
https://你的網域/webhook
```

---

## 5️⃣ Render 部署
1. 上傳 GitHub
2. Render → New Web Service
3. 選 repo
4. 加入環境變數
5. Deploy

完成後把 Render 網址填入 LINE Webhook

---

## 完成 🎉