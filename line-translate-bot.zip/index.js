import express from "express";
import line from "@line/bot-sdk";
import OpenAI from "openai";
import dotenv from "dotenv";

dotenv.config();

const app = express();

const lineConfig = {
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.LINE_CHANNEL_SECRET,
};

const client = new line.Client(lineConfig);

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

app.post("/webhook", line.middleware(lineConfig), async (req, res) => {
  try {
    await Promise.all(req.body.events.map(handleEvent));
    res.status(200).end();
  } catch (err) {
    console.error(err);
    res.status(500).end();
  }
});

async function handleEvent(event) {
  if (event.type !== "message" || event.message.type !== "text") {
    return null;
  }

  const userText = event.message.text;

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: `你是一個 LINE 即時翻譯機器人。
請自動判斷使用者輸入語言，
並翻譯成 ${process.env.TARGET_LANGUAGE}。
只輸出翻譯結果，不要解釋。`
      },
      { role: "user", content: userText }
    ]
  });

  const translated = response.choices[0].message.content.trim();

  return client.replyMessage(event.replyToken, {
    type: "text",
    text: translated
  });
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log("LINE Translate Bot running on port " + PORT);
});